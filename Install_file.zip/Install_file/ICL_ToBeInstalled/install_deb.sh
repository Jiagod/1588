#!/bin/bash

curr_dir=$(pwd)
installDebDir=$PWD/installDeb

echo "==== Install wnc_diag ====="
apt install i2c-tools --force-yes
cd $installDebDir
sudo dpkg -i wnc-diag*.deb

echo "===== End install ====="
