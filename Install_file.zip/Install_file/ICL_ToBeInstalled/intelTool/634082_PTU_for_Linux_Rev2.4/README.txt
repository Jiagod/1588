Intel® Power Thermal Utility (Intel® PTU) - Server Edition
Release Date: 03/25/2021
Copyright (C) 2021, Intel Corporation.  All rights reserved.
Intel Confidential


----------------------------------------------------------------------------------------------------------
Version: 2.4
----------------------------------------------------------------------------------------------------------
* Enabled turbo test for Signaled System Error (SSE), Intel® Advanced Vector Extensions 256 (Intel® AVX-256), Intel® Advanced Vector Extensions 512 (Intel® AVX-512) 
* Updated PMax test

----------------------------------------------------------------------------------------------------------
Version: 2.3
----------------------------------------------------------------------------------------------------------
* Enabled Ice Lake-D SoC product family 
*     Tests Supported: 
*         SSE, Intel® AVX-256, Intel® AVX-512 with power levels from 50% to 100% 
*         Thermal Design Power (TDP) and nTDP Tests
*         PMax test 

----------------------------------------------------------------------------------------------------------
Version: 2.2 
----------------------------------------------------------------------------------------------------------
* Fixed C1 state.
* Updated Intel® AVX-512 and PMax to support higher power delivery
* Allowed core and thread masks for all the CPU tests
* Fixed the PMEM monitoring data on the second socket
* Do not use cached ref_temp data

----------------------------------------------------------------------------------------------------------
Version: 2.1 
----------------------------------------------------------------------------------------------------------
* Updated Intel® Optane™ Persistent Memory (Intel® Optane™ PMem) to v1.3, changes included:
    - Support for Intel® Memory Bandwidth Boost feature at 1to120 second-time scales (sub 1 Hz operation)
* Support Intel® Optane™ PMem 200 Series individual power measurement (N-DCPPwr, N-12VPwr, N-1.2Pwr). HSD# 2207792944
* Support Intel® Optane™ PMem 200 Series FW controller and media temperature
* Support Intel® Optane™ PMem 200 Series FW thermal throttling (TLog)
* Support Intel® Optane™ PMem 200 Series FW power management policy- Intel® Memory Bandwidth Boost, PL, TC, and thresholds
* Support Ice Lake DDR-T read and write bandwidth
* Fixed IMON power report in Cooper Lake - 4. Total package power is shown in master die only. Slave die will always be 0
* Fixed bugs when specifying -logdir option
* Added -logname option to allow custom prefix filename for logging

----------------------------------------------------------------------------------------------------------
Version: 2.0
----------------------------------------------------------------------------------------------------------
* This new version of Intel® PTU is the first release of the Unified Server Intel® PTU where the  
  monitor (ptumon) and the generator (ptugen) functions are integrated into one common binary
* This Intel® PTU will also span multiple generations of legacy and upcoming CPUs
* Support DDR4 read/write bandwidth
• Command-Line Interface (CLI) usage has changed. See ptu_usage.txt for updated parameters

----------------------------------------------------------------------------------------------------------
Supported processors are: 
 Intel® Xeon® Processor Scalable Family-(SP, FPGA, W), Second Generation Intel® Xeon® Processor Scalable Family-(SP, AP), Cooper Lake-(4, 6), Ice Lake-(LCC, HCC)
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
Software Installation
----------------------------------------------------------------------------------------------------------
It is recommended to install the Intel® PTU in the /root/ptu directory
1) mkdir -p /root/ptu
2) cd /root/ptu
3) tar xvf unified_server_ptu*._gz

For Fedora* OS, the Intel® PTU driver is required to access device sensors such as DIMM temperature, 
PCH temperature and others
To install the driver, first you need to build it and then install
The driver needs to build once only, installing the driver needs to do whenever the system is rebooted

1) cd /root/ptu/driver/ptusys
2) make clean all
3) make install -> this should install the ptusys.ko file into kernel

NOTES: 
 Make sure that software and kernel development packages are installed
 yum groupinstall 'Development Tools'
 yum install kernel-devel
 
 For newer kernels, it might not build due to other missing files
 try:
 yum install "kernel-devel-$(uname -r)"
 dnd update
 yum install flex
 yum install bison
 
 if complaining missing Documentation/Kconfig, do:
 replace SUBDIRS= to M= in the Makefile

----------------------------------------------------------------------------------------------------------
Preparation for Sky Lake-FPGA SKU
----------------------------------------------------------------------------------------------------------
1) Install CentOS* 7.3-1611. FPGA software is currently not supported on other Linux* distributions
2) Go to BIOS settings and turn on "Secure Boot"
3) Verify that FPGA platform is upgraded to Blue Bitstream 6.3.0
4) Install Sky Lake-SP/FPGA Intel® PTU
   a) Log into your system as root
   b) Intel® PTU package is distributed as tar archive. cd to a <folder>, then untar the file
      tar xvfz skx_clx_ptu_rev*.tgz
5) Enroll the FPGA public key (fpga_public_cert.der) that comes with the package
   The key will be added to Machine Owner Key (MOK) list using following steps:
	a) Request addition of the public key by running following command:
		# mokutil --import <Path to the FPGA key>. You will be asked to enter and confirm a password 
		  for this MOK enrollment request. Enter any password that you can remember
	b) Reboot the machine
	c) The MokManager* will be launched to allow you to complete the enrollment from the UEFI console 
	   Choose the "Enroll MOK" option from the list in the console. You will need to enter the
	   password you previously associated with this request and confirm the enrollment 
	   Your public key is added to the MOK list, which is persistent
	d) After the machine reboots, verify that key is enrolled by running following command:
		#mokutil --test-key fpga_cert.der

NOTES:
  If you have existing Open Programmable Accelerator Engine (OPAE) drivers installed in the system, you will need to remove them before running the Intel® PTU
  In the Linux* shell, do:

  lsmod | grep fpga

  The FPGA drivers will look something like this:

  intel_fpga_fme         51339  0 
  intel_fpga_afu         27203  0 
  fpga_mgr_mod           14693  1 intel_fpga_fme
  intel_fpga_pci         25176  2 intel_fpga_afu,intel_fpga_fme

  To remove each FPGA above, do:

  rmmod intel_fpga_fme
  rmmod intel_fpga_afu
  rmmod fpga_mgr_mod
  rmmod intel_fpga_pci

----------------------------------------------------------------------------------------------------------
How to run the Intel® PTU in command-line mode:
----------------------------------------------------------------------------------------------------------
See the Intel® PTU user guide for full usage

1) Run Intel® PTU TDP:
./ptu -ct 1

2) Run Intel® PTU with nearTDP enabled:
./ptu -ct 2

3) Run Intel® PTU IA/SSE test with power level 80%:
./ptu -ct 3 -cp 80

4) Run Intel® PTU using monitor screen mode:
./ptu -mon -scr

5) Run Intel® PTU with full monitoring data and long version mode:
./ptu -mon -l 1 -filter 0xff

6) Run Intel® PTU monitor mode in level 2 and display only core 0,1:
./ptu -mon -l 2 -moncore 0x3

7) Run the Intel® Optane™ PMem 200 Series (NVDIMM) monitor mode:
,/ptu -mon -scr -l 2 -filter 0x70 -ts

----------------------------------------------------------------------------------------------------------
How to run Intel® Optane™ PMem Intel® PTU in command line mode:
----------------------------------------------------------------------------------------------------------
See the Intel® Optane™ PMem Intel® PTU user guide for full usage

1) Run thermal read test using 8 cores with a name space mounted in /mnt
./dcpmmptu -m thermals -p MAXREAD -t 1-8 -d 1000000 -n /mnt/DCPMMptu1 -s 512G -b 32M

1) Run thermal write test using 8 cores with a name space mounted in /mnt
./dcpmmptu -m thermals -p MAXWRITE -t 1-8 -d 1000000 -n /mnt/DCPMMptu1 -s 512G -b 32M

1) Run thermal read test using 8 cores on DDR4 memory
./dcpmmptu -m thermals -p MAXWRITE -t 1-8 -d 1000000 -n memory -s 512G -b 32M

----------------------------------------------------------------------------------------------------------
Known Issues / Limitations:
----------------------------------------------------------------------------------------------------------
* MCP thermal report for Crow Pass-4 is not fully implemented

----------------------------------------------------------------------------------------------------------
Troubleshooting:
----------------------------------------------------------------------------------------------------------
* Enable the Running Average Power Limit (RAPL) to see the DIMM power
* Set the PCH Thermal Device in BIOS to Enabled in the PCI mode for PCH temperature support
* PCH temperature support requires PCH B0 stepping (Sky Lake)
* Set DIMM thermal config in BIOS to CLTT mode for DIMM temperature support


----------------------------------------------------------------------------------------------------------
LEGAL / DISCLAIMERS
----------------------------------------------------------------------------------------------------------

INTEL CONFIDENTIAL
Intel technologies’ features and benefits depend on system configuration and may require enabled hardware,
software, or service activation. Learn more at intel.com, or from the OEM or retailer.

No computer system can be absolutely secure. Intel does not assume any liability for lost or stolen data
or systems or any damages resulting from such losses.

You may not use or facilitate the use of this document in connection with any infringement or other legal
analysis concerning Intel products described herein. You agree to grant Intel a non-exclusive, royalty-free
license to any patent claim thereafter drafted which includes subject matter disclosed herein.

No license (express or implied, by estoppel or otherwise) to any intellectual property rights is granted
by this document. The products described may contain design defects or errors known as errata which may
cause the product to deviate from published specifications. Current characterized errata are available
on request.

This document contains information on products, services and/or processes in development. All information
provided here is subject to change without notice. Contact your Intel representative to obtain the latest
Intel product specifications and roadmaps.

Intel disclaims all express and implied warranties, including without limitation, the implied warranties
of merchantability, fitness for a particular purpose, and non-infringement, as well as any warranty
arising from course of performance, course of dealing, or usage in trade.

Intel Corporation assumes no responsibility for errors or omissions in this document.
Nor does Intel make any commitment to update the information contained herein.

Intel does not control or audit third-party benchmark data or the web sites referenced in this document.
You should visit the referenced web site and confirm whether referenced data are accurate.

Copies of documents which have an order number and are referenced in this document may be obtained by
calling 1-800-548-4725 or by visiting www.intel.com/design/literature.htm.

Intel, Optane, and Xeon are trademarks of Intel Corporation or its subsidiaries.

*Other names and brands may be claimed as the property of others.

Copyright © 2021, Intel Corporation. All Rights Reserved.

Disclaimer: Core/Package and DIMM Power meter results are to be used only for
relative power comparisons and not for the TDP power design.

