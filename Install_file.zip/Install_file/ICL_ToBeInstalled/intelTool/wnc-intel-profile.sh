#!/bin/bash

# Expand $PATH to include the directory where intel tools commands go.
intel_bin_path="/usr/sbin/intel"
if [ -n "${PATH##*${intel_bin_path}}" -a -n "${PATH##*${intel_bin_path}:*}" ]; then
    export PATH=$PATH:${intel_bin_path}
fi