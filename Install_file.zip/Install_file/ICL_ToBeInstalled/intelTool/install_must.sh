#!/bin/bash

curr_dir=$(pwd)
kernel_ver=`uname -r`
echo "===== Start to install ====="

tar zxvf ice*.tar.gz
cd ice-1.4.0_rc24
if [ "$kernel_ver" == "5.12.4" ]; then
	patch -p1 -i ../1_ice-1.4.0_rc24_linux-5.12.4.patch
fi

return
cd $curr_dir
cd ice*/src && make && make install

cd $curr_dir
tar zxvf iavf*.tar.gz
cd iavf*/src && make && make install
echo "===== End of install ====="
