#!/bin/bash

curr_dir=$(pwd)
intel_bin_path="/usr/sbin/intel"
echo "===== Start to install ====="

rmmod iqvlinux
cd iqvlinux* && chmod +x install && ./install
modprobe iqvlinux
modinfo iqvlinux

cp $curr_dir/wnc-intel-profile.sh /etc/profile.d/
cd $curr_dir

mkdir -p $intel_bin_path
install -D -m 744 celo64e $intel_bin_path
install -D -m 744 eeupdate64e $intel_bin_path
install -D -m 744 lanconf64e $intel_bin_path

echo "===== End of install ====="
