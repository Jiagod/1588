#!/bin/bash

curr_dir=$(pwd)
installRpmDir=$PWD/installRpm

cd $installRpmDir
sudo rpm -ivh wnc-diag-*.noarch.rpm 